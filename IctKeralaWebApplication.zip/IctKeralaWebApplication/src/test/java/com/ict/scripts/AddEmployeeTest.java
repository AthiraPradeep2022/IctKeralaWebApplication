package com.ict.scripts;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import com.ict.base.Base;
import com.ict.constants.AutomationConstants;
import com.ict.pages.AddEmployee;
import com.ict.pages.HomePage;
import com.ict.pages.ListEmployee;
import com.ict.pages.LoginPage;

public class AddEmployeeTest extends Base {

	
	LoginPage objLogin;
	HomePage objHome;
	AddEmployee objAdd;
	ListEmployee objList;
	
	@BeforeMethod
	public void startUp() throws Exception {
		
		initialization();
		objLogin=new LoginPage(getDriver());
		objHome=new HomePage(getDriver());
		objAdd=new AddEmployee(getDriver());
		objList=new ListEmployee(getDriver());
		objLogin.setUsername();
		objLogin.setPassword();
		objLogin.clickLogin();
		
	}
	@AfterMethod
	public void tearDown() {
		getDriver().quit();
	}
	@Test(priority=1)
	public void verifyValidSubmit() throws Exception {
		objHome.openAddEmployee();
		objAdd.setName();
		objAdd.setPassword();
		objAdd.setEmail();
		objAdd.selectDesignation();
		objAdd.selectReporting();
		objAdd.selectMemberOf();
		objAdd.setEmpId();
		objAdd.setConfirmPwd();
		objAdd.setNumber();
		objAdd.selectEmpType();
		objAdd.selectRepStaff();
		objAdd.setAddress();
		objAdd.clickSubmit();
		String actTitle=objList.getEmpHeading();
		AssertJUnit.assertEquals(AutomationConstants.expListEmpTitle,actTitle);
		
	}
	@Test(priority=2)
	public void verifyReset() throws Exception {		
		objHome.openAddEmployee();
		objAdd.setName();
		objAdd.setPassword();
		objAdd.setEmail();
		objAdd.selectDesignation();
		objAdd.selectReporting();
		objAdd.selectMemberOf();
		objAdd.setEmpId();
		objAdd.setConfirmPwd();
		objAdd.setNumber();
		objAdd.selectEmpType();
		objAdd.selectRepStaff();
		objAdd.setAddress();
		String actName=objAdd.clickReset();
		AssertJUnit.assertEquals(objAdd.getName(),actName);
	}
	
	@Test(priority=3)
	public void verifyBack() throws Exception {
		String expUrl=getDriver().getCurrentUrl();
		objHome.openAddEmployee();		
		String actUrl=objAdd.clickBack();
		AssertJUnit.assertEquals(expUrl,actUrl);
		
	}
	@Test(priority=4)
	public void verifyNullSubmit() throws Exception {
		objHome.openAddEmployee();
		objAdd.clickSubmit();	
		Assert.assertTrue(objAdd.getValidSummary());
		
	}
	
}
