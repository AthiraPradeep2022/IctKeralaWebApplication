package com.ict.scripts;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ict.base.Base;
import com.ict.constants.AutomationConstants;
import com.ict.pages.AddEmployee;
import com.ict.pages.HomePage;
import com.ict.pages.ListEmployee;
import com.ict.pages.LoginPage;

public class ListEmployeeTest extends Base {
	LoginPage objLogin;
	HomePage objHome;
	AddEmployee objAdd;
	ListEmployee objList;

	@BeforeMethod
	public void startUp() throws Exception {
		
		initialization();
		objLogin=new LoginPage(getDriver());
		objHome=new HomePage(getDriver());
		objAdd=new AddEmployee(getDriver());
		objList=new ListEmployee(getDriver());
		objLogin.setUsername();
		objLogin.setPassword();
		objLogin.clickLogin();
		objHome.openListEmployee();
	}
	
	@AfterMethod
	public void tearDown() {
		getDriver().quit();
	}
	
	@Test(priority=1)
	public void verifyListView() {	
		int actNum=objList.getListHeading();
		Assert.assertEquals(AutomationConstants.expColNum,actNum);
	}
	
	@Test(priority=2)
	public void verifyAdd(){
		String actTitle=objList.clickAdd();
		Assert.assertEquals(AutomationConstants.expAddEmpTitle,actTitle );
	}
	@Test(priority=3)
	public void verifyEdit() {
		String actTitle=objList.clickEdit();
		Assert.assertEquals(AutomationConstants.expAddEmpTitle, actTitle);
	}
	@Test(priority=4)
	public void verifyDelete() {
		String actMsg=objList.clickDelete();
		Assert.assertEquals(AutomationConstants.expMsg, actMsg);
	}
}
