package com.ict.utilities;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class PageUtility {

	public static void sendData(WebElement element,String input) {
		
		element.sendKeys(input);
	}
	public static void clickEvent(WebElement element){

	element.click();
	}
	public static String readData(WebElement element) {
		
		return element.getText();
	}
	public static void hoverEvent(WebDriver driver,WebElement ele) {
		Actions action=new Actions(driver);
		action.moveToElement(ele).build().perform();
		
	}
	public static void dropDown(WebElement ele,String value) throws Exception {
		Select s=new Select(ele);
		s.selectByVisibleText(value);
	}
	public static void handleAlert(WebDriver driver) {
		Alert alert = driver.switchTo().alert();
		alert.accept();	
	}
	
	public static boolean chkDisplayed(WebElement ele) {
	
		return ele.isDisplayed();
	}
}
