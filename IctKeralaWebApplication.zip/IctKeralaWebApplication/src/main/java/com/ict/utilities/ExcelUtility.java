package com.ict.utilities;

import java.io.FileInputStream;

import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {

	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static String value;
	
	
	public static String getString(int row,int col) throws Exception {
		
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\com\\ict\\resources\\TestData.xlsx");
		workbook=new XSSFWorkbook(file);
		sheet=workbook.getSheetAt(0);
		value=sheet.getRow(row).getCell(col).getStringCellValue();
		return value;
		
	}
	public static String getNumber(int row,int col) throws Exception {
		
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\com\\ict\\resources\\TestData.xlsx");
		workbook=new XSSFWorkbook(file);
		sheet=workbook.getSheetAt(0);
		value=NumberToTextConverter.toText(sheet.getRow(row).getCell(col).getNumericCellValue());
		return value;
		
	}
}
