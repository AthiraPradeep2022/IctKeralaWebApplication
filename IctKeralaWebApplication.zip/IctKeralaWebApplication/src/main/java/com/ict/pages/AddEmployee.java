package com.ict.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ict.utilities.ExcelUtility;
import com.ict.utilities.PageUtility;
import com.ict.utilities.WaitUtility;

public class AddEmployee {

	WebDriver driver;
	@FindBy(id="ContentPlaceHolder1_lblTitle")
	private WebElement title;
	
	@FindBy(id="ContentPlaceHolder1_txtName")
	private WebElement nameBox;
	
	@FindBy(id="ContentPlaceHolder1_txtPassword")
	private WebElement pwdBox;
	
	@FindBy(id="ContentPlaceHolder1_txtEmail")
	private WebElement emailBox;
	
	@FindBy(id="ContentPlaceHolder1_txtEmployeeId")
	private WebElement idBox;
	
	@FindBy(id="ContentPlaceHolder1_txtConfirmPassword")
	private WebElement cpwdBox;
	
	@FindBy(id="ContentPlaceHolder1_txtMobileNumber")
	private WebElement mobBox;
	
	@FindBy(id="ContentPlaceHolder1_txtAddress")
	private WebElement adrBox;
	
	@FindBy(id="ContentPlaceHolder1_drpDesignation")
	private WebElement designationList;
	
	@FindBy(id="ContentPlaceHolder1_drpReportingTo")
	private WebElement reportingList;
	
	@FindBy(id="ContentPlaceHolder1_drpGroup")
	private WebElement memberList;
	
	@FindBy(id="ContentPlaceHolder1_drpEmployeeType")
	private WebElement typeList;

	@FindBy(id="ContentPlaceHolder1_ChkReportingStaff")
	private WebElement chkBox;

	@FindBy(id="ContentPlaceHolder1_btnSubmit")
	private WebElement submitBtn;

	@FindBy(id="Reset")
	private WebElement resetBtn;

	@FindBy(id="ContentPlaceHolder1_btnBack")
	private WebElement backBtn;

	@FindBy(id="ContentPlaceHolder1_ValidationSummary")
	private WebElement validSummary;
	
	public AddEmployee(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setName() throws Exception {
		PageUtility.sendData(nameBox, ExcelUtility.getString(2, 0));
	}
	public void setPassword() throws Exception {
		PageUtility.sendData(pwdBox, ExcelUtility.getString(2, 1));
	}
	public void setConfirmPwd() throws Exception {
		PageUtility.sendData(cpwdBox, ExcelUtility.getString(2, 2));
	}
	public void setEmail() throws Exception {
		PageUtility.sendData(emailBox, ExcelUtility.getString(2, 4));
	}
	public void setEmpId() throws Exception {
		PageUtility.sendData(idBox, ExcelUtility.getNumber(2, 3));
	}
	public void setNumber() throws Exception {
		PageUtility.sendData(mobBox, ExcelUtility.getNumber(2, 9));
	}
	public void selectDesignation() throws Exception {
		PageUtility.dropDown(designationList, ExcelUtility.getString(2, 5));
	}
	public void selectReporting() throws Exception {
		
		PageUtility.dropDown(reportingList, ExcelUtility.getString(2, 6));
	}
	public void selectMemberOf() throws Exception {
		PageUtility.dropDown(memberList, ExcelUtility.getString(2, 7));
	}
	public void selectEmpType() throws Exception {
		PageUtility.dropDown(typeList, ExcelUtility.getString(2, 8));
	}
	public void selectRepStaff() throws Exception {
	
		if(ExcelUtility.getString(2,11).equalsIgnoreCase("Yes"))
		{
			PageUtility.clickEvent(chkBox);
		}
	}
	public void setAddress() throws Exception {
		PageUtility.sendData(adrBox, ExcelUtility.getString(2, 10));
	}
	public void clickSubmit() {

		PageUtility.clickEvent(submitBtn);
		
	}
	public String clickReset() {
		PageUtility.clickEvent(resetBtn);
		return PageUtility.readData(nameBox);
	}
	public String clickBack() {
		
		PageUtility.clickEvent(backBtn);
		String actUrl=driver.getCurrentUrl();
		return actUrl;
	}
	public String getTitle() {
		
		return PageUtility.readData(title);
	}
	public String getName() {
		return PageUtility.readData(nameBox);
	}
	public boolean getValidSummary() {
		boolean bool=PageUtility.chkDisplayed(validSummary);
		return bool;
		
	}
}
