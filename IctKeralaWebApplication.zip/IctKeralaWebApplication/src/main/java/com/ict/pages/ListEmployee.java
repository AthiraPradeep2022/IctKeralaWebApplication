package com.ict.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ict.utilities.ExcelUtility;
import com.ict.utilities.PageUtility;
import com.ict.utilities.WaitUtility;

public class ListEmployee {

	WebDriver driver;
	
	@FindBy(xpath="//span[text()=\"Employees\"]")
	private WebElement empHeading;
	
	@FindBy(xpath="//table[@id=\"ContentPlaceHolder1_gvList\"]/tbody/tr/th")
	private List<WebElement> listHeading;
	
	@FindBy(id="addButton")
	private WebElement addBtn;
	
	@FindBy(linkText="Edit")
	private WebElement editBtn;
	
	@FindBy(linkText="Delete")
	private WebElement deleteBtn;
	
	@FindBy(id="ContentPlaceHolder1_lblMsg")
	private WebElement dltMsg;
	
	public ListEmployee(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public String getEmpHeading() {
		WaitUtility.waitForEle(driver, empHeading);
		return PageUtility.readData(empHeading);
		
	}
	public int getListHeading() {
		
		return listHeading.size();
	}
	public String clickAdd() {
		AddEmployee objAdd=new AddEmployee(driver);
		PageUtility.clickEvent(addBtn);
		return objAdd.getTitle();
	}
	public String clickEdit() {
		AddEmployee objAdd=new AddEmployee(driver);
		PageUtility.clickEvent(editBtn);
		return objAdd.getTitle();
	}
	public String clickDelete() {
		PageUtility.clickEvent(deleteBtn);
		PageUtility.handleAlert(driver);
		return dltMsg.getText();
	}
}
