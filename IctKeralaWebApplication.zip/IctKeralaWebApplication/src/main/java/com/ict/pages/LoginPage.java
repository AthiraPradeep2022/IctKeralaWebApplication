package com.ict.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ict.utilities.ExcelUtility;
import com.ict.utilities.PageUtility;

public class LoginPage {

	WebDriver driver;
	
	@FindBy(id="txtUsername")
	private WebElement unameBox;
	
	@FindBy(id="txtPassword")
	private WebElement pwdBox;
	
	@FindBy(id="btnSubmit")
	private WebElement loginBtn;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setUsername() throws Exception {

		PageUtility.sendData(unameBox,ExcelUtility.getString(0, 0));
	}
	public void setPassword() throws Exception {

		PageUtility.sendData(pwdBox,ExcelUtility.getNumber(0, 1));
	}
	public void clickLogin() throws Exception {

		PageUtility.clickEvent(loginBtn);
	}
}
