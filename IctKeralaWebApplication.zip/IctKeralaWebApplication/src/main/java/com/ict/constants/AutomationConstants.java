package com.ict.constants;

public class AutomationConstants {

	public static String expListEmpTitle="Employees";
	public static String expAddEmpTitle="Add";
	public static int expColNum=4;
	public static String expName="Athira Pradeep";
	public static String expDesignation="Project Co-ordinator";
	public static String expMsg="Deleted the employee successfully!!!";
}
